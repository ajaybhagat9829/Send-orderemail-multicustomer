<?php
namespace DigitalBuff\Custemailcustomer\Controller\Adminhtml\Order;

use Magento\Backend\App\Action;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
class CustomAction extends Action
{
    const ADMIN_RESOURCE = 'Magento_Sales::sales_order';
    /**
     * @var OrderCollectionFactory
     */
    protected $orderCollectionFactory;
    /**
     * ChangeColor constructor.
     * @param Action\Context $context
     * @param OrderCollectionFactory $orderCollectionFactory
     */
    public function __construct(
        Action\Context $context,
        OrderCollectionFactory $orderCollectionFactory
    ) {
        $this->orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context);
    }
    public function execute()
    {

        $request = $this->getRequest();
      
        $orderIds = $request->getPost('selected', []);
       
        if (empty($orderIds)) {
            $this->getMessageManager()->addErrorMessage(__('No orders found.'));
            return $this->_redirect('sales/order/index');
        }
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addFieldToFilter('entity_id', ['in' => $orderIds]);
        try {
            foreach ($orderCollection as $order) {
             $objectManager = \Magento\Framework\App\ObjectManager::getInstance();        
             $emailSender = $objectManager->create('\Magento\Sales\Model\Order\Email\Sender\OrderSender');
             $emailSender->send($order);
            }
        } catch (\Exception $e) {
            $message = "An unknown error occurred while changing selected orders.";
            $this->getMessageManager()->addErrorMessage(__($message));
        }
        $message = "Mail sent successfully.";
            $this->getMessageManager()->addSuccessMessage(__($message));
        return $this->_redirect('sales/order/index');
    }
}